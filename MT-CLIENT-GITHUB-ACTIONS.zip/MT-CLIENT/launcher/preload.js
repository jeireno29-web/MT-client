const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('mtClient', {
  getVersion: () => ipcRenderer.invoke('app:get-version'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setMicrosoftClientId: (id) => ipcRenderer.invoke('settings:set-client-id', id),
  launchGame: (selection) => ipcRenderer.invoke('game:launch', selection),
  onGameStatus: (callback) => ipcRenderer.on('game:status', (_event, message) => callback(message)),
  openExternal: (url) => ipcRenderer.invoke('app:open-external', url)
});
