const pages = [...document.querySelectorAll('.page')];
const navs = [...document.querySelectorAll('.nav')];
const crumb = document.getElementById('crumb');
const toast = document.getElementById('toast');
let toastTimer;
function notify(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 4200);
}
function showPage(name) {
  pages.forEach(page => page.classList.toggle('active', page.id === name));
  navs.forEach(button => button.classList.toggle('active', button.dataset.page === name));
  crumb.textContent = ({home:'Inicio',mods:'Mods',profiles:'Perfiles',settings:'Ajustes'})[name] || 'Inicio';
}
navs.forEach(button => button.addEventListener('click', () => showPage(button.dataset.page)));
document.querySelectorAll('[data-go]').forEach(button => button.addEventListener('click', () => showPage(button.dataset.go)));

const statusEl = document.getElementById('game-status');
window.mtClient?.onGameStatus((message) => { statusEl.textContent = message; });
document.getElementById('play-button').addEventListener('click', async () => {
  const selection = {
    version: document.getElementById('version-select').value,
    loader: document.getElementById('loader-select').value,
    memory: Number(document.getElementById('ram').value)
  };
  statusEl.textContent = 'Conectando con el instalador…';
  try {
    await window.mtClient.launchGame(selection);
    notify('Solicitud de inicio enviada.');
  } catch (error) {
    statusEl.textContent = error.message;
    notify(error.message);
  }
});

document.getElementById('save-client-id').addEventListener('click', async () => {
  const value = document.getElementById('microsoft-client-id').value.trim();
  try {
    await window.mtClient.setMicrosoftClientId(value);
    notify('ID de aplicación guardado.');
  } catch (error) { notify(error.message); }
});
document.getElementById('ms-docs').addEventListener('click', () => {
  window.mtClient.openExternal('https://learn.microsoft.com/en-us/entra/identity-platform/quickstart-register-app');
});
window.mtClient?.getSettings().then(settings => {
  document.getElementById('microsoft-client-id').value = settings.microsoftClientId || '';
  document.getElementById('ram').value = String(settings.defaultMemoryGb || 4);
}).catch(() => {});
window.mtClient?.getVersion().then(version => {
  document.getElementById('app-version').textContent = version;
}).catch(() => {
  document.getElementById('app-version').textContent = '0.3.0';
});
