const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('node:path');
const fs = require('node:fs');

let mainWindow;
let running = false;
const settingsPath = path.join(app.getPath('userData'), 'settings.json');
function readSettings() {
  try { return JSON.parse(fs.readFileSync(settingsPath, 'utf8')); }
  catch {
    try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'config', 'settings.json'), 'utf8')); }
    catch { return { microsoftClientId: '', defaultMemoryGb: 4 }; }
  }
}
function sendStatus(message) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('game:status', message);
}
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1180, height: 760, minWidth: 900, minHeight: 620,
    backgroundColor: '#09090d', title: 'MT CLIENT',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, nodeIntegration: false, sandbox: true
    }
  });
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('app:get-version', () => app.getVersion());
ipcMain.handle('app:open-external', async (_event, url) => {
  const allowed = ['https://www.minecraft.net/', 'https://www.microsoft.com/', 'https://learn.microsoft.com/'];
  if (typeof url !== 'string' || !allowed.some(base => url.startsWith(base))) return false;
  await shell.openExternal(url);
  return true;
});
ipcMain.handle('settings:get', () => {
  const s = readSettings();
  return { microsoftClientId: s.microsoftClientId || '', defaultMemoryGb: s.defaultMemoryGb || 4 };
});
ipcMain.handle('settings:set-client-id', (_event, clientId) => {
  if (typeof clientId !== 'string' || clientId.length > 100 || (clientId && !/^[a-f0-9-]{36}$/i.test(clientId.trim()))) {
    throw new Error('El ID de aplicación no tiene un formato válido.');
  }
  const s = readSettings();
  s.microsoftClientId = clientId.trim();
  fs.mkdirSync(path.dirname(settingsPath), { recursive: true });
  fs.writeFileSync(settingsPath, JSON.stringify(s, null, 2));
  return true;
});

ipcMain.handle('game:launch', async (_event, selection) => {
  if (running) throw new Error('Minecraft ya se está iniciando.');
  const version = String(selection?.version || '');
  const loader = String(selection?.loader || 'vanilla').toLowerCase();
  const memory = Number(selection?.memory || 4);
  const allowedVersions = ['1.21.10','1.21.8','1.21.4','1.21.1','1.20.6','1.20.1','1.19.4'];
  if (!allowedVersions.includes(version)) throw new Error('Selecciona una versión disponible.');
  if (!['vanilla','fabric','forge','neoforge'].includes(loader)) throw new Error('Cargador no válido.');
  if (![2,4,6,8].includes(memory)) throw new Error('Memoria no válida.');

  const settings = readSettings();
  if (!settings.microsoftClientId) {
    throw new Error('Primero configura el ID de aplicación de Microsoft en Ajustes.');
  }
  running = true;
  try {
    sendStatus('Abriendo el inicio de sesión oficial de Microsoft…');
    // The core performs official Microsoft/Xbox/Minecraft authentication and installs the selected profile.
    const { Launch, Microsoft } = await import('minecraft-java-core');
    const authenticator = await Microsoft.auth({ client_id: settings.microsoftClientId, type: 'electron' });
    if (!authenticator) throw new Error('No se completó el inicio de sesión.');
    sendStatus(`Preparando Minecraft ${version}${loader === 'vanilla' ? '' : ` · ${loader}`}…`);
    const launcher = new Launch();
    launcher.on?.('progress', (progress) => sendStatus(`Descargando archivos… ${typeof progress === 'number' ? `${Math.round(progress)}%` : ''}`));
    launcher.on?.('data', (line) => sendStatus(String(line).slice(0, 180)));
    launcher.on?.('close', () => { running = false; sendStatus('Minecraft se cerró.'); });
    const root = path.join(app.getPath('userData'), 'minecraft');
    await launcher.launch({
      root,
      authenticator,
      version,
      ...(loader === 'vanilla' ? {} : { loader: { type: loader } }),
      memory: { min: '2G', max: `${memory}G` }
    });
    return { started: true };
  } catch (error) {
    running = false;
    sendStatus('No se pudo iniciar Minecraft.');
    throw new Error(error?.message || 'Error al iniciar Minecraft.');
  }
});
