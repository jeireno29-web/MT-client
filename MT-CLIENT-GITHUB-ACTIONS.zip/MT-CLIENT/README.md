# MT CLIENT v0.3.0

Prototipo de launcher de escritorio para Minecraft Java (Windows 10/11), con interfaz negra y roja y selección de Vanilla, Fabric, Forge y NeoForge.

## Requisitos
- Windows 10 u 11 de 64 bits.
- Node.js LTS (18 o posterior).
- Una cuenta Microsoft que tenga Minecraft: Java Edition.
- Un ID de aplicación Microsoft configurado para el flujo de autenticación que use la biblioteca.

## Ejecutar en modo desarrollo
1. Instala Node.js LTS.
2. Extrae el ZIP en una carpeta.
3. Abre una terminal dentro de `MT-CLIENT`.
4. Ejecuta `npm install`.
5. Ejecuta `npm start`.
6. En Ajustes, configura el ID de aplicación Microsoft y pulsa **Guardar ID**.
7. En Inicio, elige versión, cargador y RAM; pulsa **Jugar**.

## Crear instalador de Windows
En una terminal dentro de la carpeta del proyecto ejecuta:

```bash
npm run pack
```

El instalador se generará en `dist/` si la compilación termina correctamente.

## Configuración Microsoft
El campo de ID de aplicación acepta un identificador GUID público de una aplicación registrada. Consulta la documentación oficial enlazada desde Ajustes. No introduzcas tu contraseña Microsoft en MT CLIENT; el inicio de sesión debe abrirse en el flujo oficial. El ID no es una contraseña ni un secreto.

## Estado y limitaciones
- Incluye la interfaz y la conexión inicial con `minecraft-java-core` para autenticación Microsoft, descarga/preparación e inicio del juego.
- La instalación de loaders depende de las versiones y builds que la biblioteca y sus metadatos soporten. No todas las combinaciones de Minecraft/loader están garantizadas.
- Esta versión todavía necesita pruebas reales en Windows con una aplicación Microsoft configurada. No se ha generado un `.exe` en este paquete.
- Mods, perfiles avanzados, cosméticos y HUD personalizado aún no están implementados.
- Usa Java Edition legítimo y respeta las condiciones de Microsoft/Mojang.

MT CLIENT es un proyecto independiente y no está afiliado a Mojang ni Microsoft.
